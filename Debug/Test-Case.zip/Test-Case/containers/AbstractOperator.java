/**
 * 
 */
package containers;

/**
 * @author arjun
 *
 */
public interface AbstractOperator {

	abstract void initDataPoints();
	abstract void performOperation();
	
}
